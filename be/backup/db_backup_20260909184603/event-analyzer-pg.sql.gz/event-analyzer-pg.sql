--
-- PostgreSQL database dump
--

\restrict 64vIA8rUPCaotQHJS0bHym7SUb16Bhygg6NdCLIXVbgyWcIJXt1KT4fh0bJzX5u

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analysis (
    id integer NOT NULL,
    event_id integer,
    summary text,
    reason text,
    solutions text,
    func text,
    severity text,
    service text,
    confidence real,
    actions jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: analysis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.analysis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: analysis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.analysis_id_seq OWNED BY public.analysis.id;


--
-- Name: analysis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analysis ALTER COLUMN id SET DEFAULT nextval('public.analysis_id_seq'::regclass);


--
-- Data for Name: analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analysis (id, event_id, summary, reason, solutions, func, severity, service, confidence, actions, created_at, updated_at) FROM stdin;
\.


--
-- Name: analysis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.analysis_id_seq', 1, false);


--
-- Name: analysis PK_300795d51c57ef52911ed65851f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analysis
    ADD CONSTRAINT "PK_300795d51c57ef52911ed65851f" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict 64vIA8rUPCaotQHJS0bHym7SUb16Bhygg6NdCLIXVbgyWcIJXt1KT4fh0bJzX5u

