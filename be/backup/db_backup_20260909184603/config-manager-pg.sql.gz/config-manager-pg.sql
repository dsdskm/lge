--
-- PostgreSQL database dump
--

\restrict tjGuCxELCXyY82O0OcxFR15KOLkyz3lJ18KymoVFutekaGAfKWYKyFEn89O6THO

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assignees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assignees (
    id integer NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    team text NOT NULL,
    profile text DEFAULT ''::text NOT NULL,
    func text NOT NULL,
    tags json DEFAULT '[]'::json NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: assignees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assignees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assignees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assignees_id_seq OWNED BY public.assignees.id;


--
-- Name: event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event (
    id integer NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_id_seq OWNED BY public.event.id;


--
-- Name: funcs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funcs (
    id integer NOT NULL,
    func text DEFAULT 'default'::text NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    description text,
    prompt text,
    assignees jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: funcs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.funcs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: funcs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.funcs_id_seq OWNED BY public.funcs.id;


--
-- Name: llm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm (
    id integer NOT NULL,
    provider text NOT NULL,
    instruction text NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: llm_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.llm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: llm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.llm_id_seq OWNED BY public.llm.id;


--
-- Name: report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report (
    id integer NOT NULL,
    "singletonKey" character varying(32) DEFAULT 'default'::character varying NOT NULL,
    "subjectTemplate" text NOT NULL,
    "htmlTemplate" text NOT NULL,
    description character varying(255) DEFAULT ''::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_id_seq OWNED BY public.report.id;


--
-- Name: assignees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignees ALTER COLUMN id SET DEFAULT nextval('public.assignees_id_seq'::regclass);


--
-- Name: event id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event ALTER COLUMN id SET DEFAULT nextval('public.event_id_seq'::regclass);


--
-- Name: funcs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funcs ALTER COLUMN id SET DEFAULT nextval('public.funcs_id_seq'::regclass);


--
-- Name: llm id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm ALTER COLUMN id SET DEFAULT nextval('public.llm_id_seq'::regclass);


--
-- Name: report id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report ALTER COLUMN id SET DEFAULT nextval('public.report_id_seq'::regclass);


--
-- Data for Name: assignees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assignees (id, email, name, team, profile, func, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event (id, key, value, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: funcs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.funcs (id, func, tags, description, prompt, assignees, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llm; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm (id, provider, instruction, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report (id, "singletonKey", "subjectTemplate", "htmlTemplate", description, enabled, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: assignees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assignees_id_seq', 1, false);


--
-- Name: event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_id_seq', 1, false);


--
-- Name: funcs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.funcs_id_seq', 1, false);


--
-- Name: llm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.llm_id_seq', 1, false);


--
-- Name: report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.report_id_seq', 1, false);


--
-- Name: event PK_30c2f3bbaf6d34a55f8ae6e4614; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT "PK_30c2f3bbaf6d34a55f8ae6e4614" PRIMARY KEY (id);


--
-- Name: llm PK_4e823c22c401c64e2ba852f8541; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm
    ADD CONSTRAINT "PK_4e823c22c401c64e2ba852f8541" PRIMARY KEY (id);


--
-- Name: assignees PK_8abd9183a32f7dd03164790b8c7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignees
    ADD CONSTRAINT "PK_8abd9183a32f7dd03164790b8c7" PRIMARY KEY (id);


--
-- Name: report PK_99e4d0bea58cba73c57f935a546; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT "PK_99e4d0bea58cba73c57f935a546" PRIMARY KEY (id);


--
-- Name: funcs PK_d8679a5f47b8ae846c6eccff714; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funcs
    ADD CONSTRAINT "PK_d8679a5f47b8ae846c6eccff714" PRIMARY KEY (id);


--
-- Name: llm UQ_1b9bb7410360d3b36d6f5747243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm
    ADD CONSTRAINT "UQ_1b9bb7410360d3b36d6f5747243" UNIQUE (provider);


--
-- Name: funcs UQ_3625a396be63a45200c45fd2837; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funcs
    ADD CONSTRAINT "UQ_3625a396be63a45200c45fd2837" UNIQUE (func);


--
-- Name: event UQ_ad0cba9e30cce3d2e557a37bb37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT "UQ_ad0cba9e30cce3d2e557a37bb37" UNIQUE (key);


--
-- Name: IDX_assignees_func; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_assignees_func" ON public.assignees USING btree (func);


--
-- Name: UQ_assignees_func_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UQ_assignees_func_email" ON public.assignees USING btree (func, email);


--
-- PostgreSQL database dump complete
--

\unrestrict tjGuCxELCXyY82O0OcxFR15KOLkyz3lJ18KymoVFutekaGAfKWYKyFEn89O6THO

