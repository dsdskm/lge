--
-- PostgreSQL database dump
--

\restrict rIto7DLXhwPGdkmwUQhskdmVIMwUnlvgg0M8eVsGQnHXbvM0VTlVOl5Qp8fEJUe

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assignees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assignees (
    id integer NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    team text NOT NULL,
    profile text DEFAULT ''::text NOT NULL,
    func text NOT NULL,
    tags json DEFAULT '[]'::json NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: assignees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assignees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assignees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assignees_id_seq OWNED BY public.assignees.id;


--
-- Name: event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event (
    id integer NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_id_seq OWNED BY public.event.id;


--
-- Name: funcs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funcs (
    id integer NOT NULL,
    func text DEFAULT 'default'::text NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    description text,
    prompt text,
    assignees jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: funcs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.funcs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: funcs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.funcs_id_seq OWNED BY public.funcs.id;


--
-- Name: llm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm (
    id integer NOT NULL,
    provider text NOT NULL,
    instruction text NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: llm_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.llm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: llm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.llm_id_seq OWNED BY public.llm.id;


--
-- Name: report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report (
    id integer NOT NULL,
    "singletonKey" character varying(32) DEFAULT 'default'::character varying NOT NULL,
    "subjectTemplate" text NOT NULL,
    "htmlTemplate" text NOT NULL,
    description character varying(255) DEFAULT ''::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_id_seq OWNED BY public.report.id;


--
-- Name: assignees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignees ALTER COLUMN id SET DEFAULT nextval('public.assignees_id_seq'::regclass);


--
-- Name: event id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event ALTER COLUMN id SET DEFAULT nextval('public.event_id_seq'::regclass);


--
-- Name: funcs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funcs ALTER COLUMN id SET DEFAULT nextval('public.funcs_id_seq'::regclass);


--
-- Name: llm id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm ALTER COLUMN id SET DEFAULT nextval('public.llm_id_seq'::regclass);


--
-- Name: report id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report ALTER COLUMN id SET DEFAULT nextval('public.report_id_seq'::regclass);


--
-- Data for Name: assignees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assignees (id, email, name, team, profile, func, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event (id, key, value, updated_by, created_at, updated_at) FROM stdin;
1	error_context_lines	5	system-seed	2026-09-16 00:18:43.644294+00	2026-09-16 00:18:43.644294+00
\.


--
-- Data for Name: funcs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.funcs (id, func, tags, description, prompt, assignees, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llm; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm (id, provider, instruction, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report (id, "singletonKey", "subjectTemplate", "htmlTemplate", description, enabled, "createdAt", "updatedAt") FROM stdin;
1	default	[{eventId}]{summary}	<div style="margin:0;padding:24px 12px;background:#eef1f5;font-family:'Apple SD Gothic Neo','Malgun Gothic','Segoe UI',sans-serif;color:#1f2933;">\n  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">\n    <tr><td align="center">\n      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="width:600px;max-width:600px;border-collapse:collapse;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 10px 30px rgba(15,23,42,0.12);">\n        <tr><td style="padding:28px 32px;background:linear-gradient(135deg,#0b2a4a 0%,#1b6ca8 100%);">\n          <div style="font-size:11px;letter-spacing:0.18em;color:#9ec5e6;font-weight:600;">AI LOG REPORT</div>\n          <div style="margin-top:8px;font-size:24px;font-weight:700;color:#ffffff;line-height:1.25;">이슈 분석 리포트</div>\n          <div style="margin-top:10px;font-size:13px;color:#cfe0ef;">#{eventId} · {robotId}</div>\n        </td></tr>\n        <tr><td style="padding:24px 32px 8px;">\n          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:separate;border-spacing:0;">\n            <tr>\n              <td style="padding:0 0 14px;width:50%;vertical-align:top;">\n                <div style="font-size:11px;color:#8a94a6;letter-spacing:0.04em;">기능</div>\n                <div style="margin-top:4px;font-size:15px;font-weight:700;color:#10243b;">{funcKey}</div>\n              </td>\n              <td style="padding:0 0 14px;width:50%;vertical-align:top;">\n                <div style="font-size:11px;color:#8a94a6;letter-spacing:0.04em;">심각도</div>\n                <div style="margin-top:4px;"><span style="display:inline-block;padding:3px 12px;border-radius:999px;background:#fdecec;color:#c0392b;font-size:13px;font-weight:700;">{severity}</span></div>\n              </td>\n            </tr>\n            <tr>\n              <td style="padding:0;width:50%;vertical-align:top;">\n                <div style="font-size:11px;color:#8a94a6;letter-spacing:0.04em;">분석 LLM</div>\n                <div style="margin-top:4px;font-size:15px;font-weight:600;color:#10243b;">{provider}</div>\n              </td>\n              <td style="padding:0;width:50%;vertical-align:top;">\n                <div style="font-size:11px;color:#8a94a6;letter-spacing:0.04em;">생성 날짜</div>\n                <div style="margin-top:4px;font-size:15px;font-weight:600;color:#10243b;">{createdAt}</div>\n              </td>\n            </tr>\n          </table>\n        </td></tr>\n        <tr><td style="padding:8px 32px;"><div style="height:1px;background:#eceff3;"></div></td></tr>\n        <tr><td style="padding:8px 32px 4px;">\n          <div style="font-size:12px;font-weight:700;color:#1b6ca8;letter-spacing:0.03em;border-left:3px solid #1b6ca8;padding-left:8px;">이슈 원인</div>\n          <p style="margin:10px 0 0;font-size:14px;line-height:1.7;color:#33414f;white-space:pre-wrap;">{summary}</p>\n        </td></tr>\n        <tr><td style="padding:18px 32px 4px;">\n          <div style="font-size:12px;font-weight:700;color:#1b6ca8;letter-spacing:0.03em;border-left:3px solid #1b6ca8;padding-left:8px;">솔루션</div>\n          <p style="margin:10px 0 0;font-size:14px;line-height:1.7;color:#33414f;white-space:pre-wrap;">{solutions}</p>\n        </td></tr>\n        <tr><td style="padding:18px 32px 28px;">\n          <div style="font-size:12px;font-weight:700;color:#1b6ca8;letter-spacing:0.03em;border-left:3px solid #1b6ca8;padding-left:8px;">후속 추천 액션</div>\n          <div style="margin-top:10px;padding:16px 18px;background:#f3f8fd;border:1px solid #d6e6f5;border-radius:12px;">\n            <p style="margin:0;font-size:14px;line-height:1.8;color:#10406b;white-space:pre-wrap;">{actions}</p>\n          </div>\n        </td></tr>\n        <tr><td style="padding:16px 32px;background:#f7f9fb;border-top:1px solid #eceff3;">\n          <div style="font-size:12px;color:#9aa4b2;">본 메일은 AI Log System에서 자동 발송되었습니다.</div>\n        </td></tr>\n      </table>\n    </td></tr>\n  </table>\n</div>	기본 리포트 템플릿	t	2026-09-16 00:18:46.498365+00	2026-09-16 00:18:46.498365+00
\.


--
-- Name: assignees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assignees_id_seq', 1, false);


--
-- Name: event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_id_seq', 1, true);


--
-- Name: funcs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.funcs_id_seq', 1, false);


--
-- Name: llm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.llm_id_seq', 1, false);


--
-- Name: report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.report_id_seq', 1, true);


--
-- Name: event PK_30c2f3bbaf6d34a55f8ae6e4614; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT "PK_30c2f3bbaf6d34a55f8ae6e4614" PRIMARY KEY (id);


--
-- Name: llm PK_4e823c22c401c64e2ba852f8541; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm
    ADD CONSTRAINT "PK_4e823c22c401c64e2ba852f8541" PRIMARY KEY (id);


--
-- Name: assignees PK_8abd9183a32f7dd03164790b8c7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assignees
    ADD CONSTRAINT "PK_8abd9183a32f7dd03164790b8c7" PRIMARY KEY (id);


--
-- Name: report PK_99e4d0bea58cba73c57f935a546; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT "PK_99e4d0bea58cba73c57f935a546" PRIMARY KEY (id);


--
-- Name: funcs PK_d8679a5f47b8ae846c6eccff714; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funcs
    ADD CONSTRAINT "PK_d8679a5f47b8ae846c6eccff714" PRIMARY KEY (id);


--
-- Name: llm UQ_1b9bb7410360d3b36d6f5747243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm
    ADD CONSTRAINT "UQ_1b9bb7410360d3b36d6f5747243" UNIQUE (provider);


--
-- Name: funcs UQ_3625a396be63a45200c45fd2837; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funcs
    ADD CONSTRAINT "UQ_3625a396be63a45200c45fd2837" UNIQUE (func);


--
-- Name: event UQ_ad0cba9e30cce3d2e557a37bb37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT "UQ_ad0cba9e30cce3d2e557a37bb37" UNIQUE (key);


--
-- Name: IDX_assignees_func; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_assignees_func" ON public.assignees USING btree (func);


--
-- Name: UQ_assignees_func_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UQ_assignees_func_email" ON public.assignees USING btree (func, email);


--
-- PostgreSQL database dump complete
--

\unrestrict rIto7DLXhwPGdkmwUQhskdmVIMwUnlvgg0M8eVsGQnHXbvM0VTlVOl5Qp8fEJUe

